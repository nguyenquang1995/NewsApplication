package com.example.newsapplication;

public class MainActivityPresenter {
    private View view;

    public MainActivityPresenter(View view) {
        this.view = view;
    }

    public interface View{
        void goToDetail();
        void showProgressBar();
        void hideProgressBar();
    }
}
