package com.example.newsapplication;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.newsapplication.dummy.DummyContent;

import java.util.List;

public class MainActivity extends AppCompatActivity implements MainActivityPresenter.View{
    RecyclerView recyclerView;
    MainActivityPresenter presenter;
    ProgressDialog dialogue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle(getTitle());

        recyclerView = findViewById(R.id.rv_item_list);
        LinearLayoutManager linearLayoutManager  = new LinearLayoutManager(getBaseContext(),LinearLayoutManager.VERTICAL,false);
        recyclerView.setLayoutManager(linearLayoutManager);

        presenter = new MainActivityPresenter(MainActivity.this);
        dialogue = new ProgressDialog(this);
        dialogue.setTitle("Loading items..");
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    public void goToDetail() {

    }

    @Override
    public void showProgressBar() {
        dialogue.show();
    }

    @Override
    public void hideProgressBar() {
        dialogue.dismiss();
    }
}
