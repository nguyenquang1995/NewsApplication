package com.example.newsapplication;

public class NewsObject {
}
